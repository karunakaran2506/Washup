module.exports = {
    mongoURI : 'mongodb+srv://ksashanmu:Shanmu1522@ksa2022.m7x5x.mongodb.net/ksaccmeet2022?retryWrites=true&w=majority'
}