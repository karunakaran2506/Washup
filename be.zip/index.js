const mongoose = require('mongoose')
const express = require('express')
const port = 3000;
const conn = express();
const cors = require('cors')
const uri = require('./config/key').mongoURI
const bodyParser = require('body-parser')




mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
mongoose.connection.once('open', function () {
    console.log('connection has been made');
}).on('error', function (error) {
    console.log('error is:', error);
})


conn.use(express.json())
conn.use(bodyParser.urlencoded({ extended: true }))
conn.use(bodyParser.json())
conn.use(cors());
const routes = require('./data/routes/route');
conn.use('/ksaccmeet', routes)


conn.listen(port, function () {
    console.log(`server started on port ${port}`);
})