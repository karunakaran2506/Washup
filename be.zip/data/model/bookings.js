const mongoose = require('mongoose')
const Schema = mongoose.Schema



const BookingSchema = new Schema({
    name: {
        type: String,
     
    },
    board: {
        type: String,        
    },
    email: {
        type: String,
   
        // match: /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/
    },
    phonenumber: {
        type: String,
        unique:true
    },
    HighestDegree: {
        type: String
    },
    gender: {
        type: String
    },
    partiattending: {
        type: String
    },
    parti: {
        type: String
    },
    school: {
        type: String
    },
    dob: {
        type: String
    },
    collegename: {
        type: String
    },
    stream:{
        type: String
    },
    parentName: {
        type: String
    },
    parentPhone: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    address:{
        type: String
    },
    OrderId:{
        type:String
    },  
    ccmeet:{
        type:String
    } ,
    date: {
        type: Date,
        
    },
    day:{
        type:String
    },
    timing: {
        type: String
    },
    amount: {
        type: Number
    },
    razorpayOrderId: {
        type: String
    },
    razorpayPaymentId: {
        type: String
    },
    createdAt: {
        type: Date,
      
        default: Date.now
    },
    reference:{
        type:String
    },
    status:{
        type:String,
        default:"created"
    }
});

module.exports = mongoose.model("bookings", BookingSchema)