const mongoose = require('mongoose')
const Schema = mongoose.Schema
const moment = require('moment-timezone');
const date = moment.tz(Date.now(), "Asia/Kolkata");

const OnetoOneSchema = new Schema({
    maxUser: {
        type: Number,
        default: 1
    },
    currentUser: {
        type: Number,
        default: 0
    },
    date: {
        type: Date,
        required: true
    },
    dateString:{
        type:String
    },
    day:{
        type:String
    },
    timing: {
        type: String
    },
    Amount: {
        type: Number
    },
    isActive: {
        type: Number
    },
    createdAt: {
        type: Date,
        required: true,
        default: date
    }
});

module.exports = mongoose.model("onetoone", OnetoOneSchema)