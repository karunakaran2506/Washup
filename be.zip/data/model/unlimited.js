const mongoose = require('mongoose')
const Schema = mongoose.Schema



const UnlimitedSchema = new Schema({
    currentUser: {
        type: Number,
        default: 0
    },
    date: {
        type: Date,
        required: true
    },
    dateString:{
        type:String
    },
    day:{
        type:String
    },
    timing: {
        type: String
    },
    isActive: {
        type: Number
    },
    createdAt: {
        type: Date,
        required: true,
        default: Date.now
    }
});

module.exports = mongoose.model("unlimiteds", UnlimitedSchema)