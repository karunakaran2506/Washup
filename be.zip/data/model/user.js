const mongoose = require('mongoose')
const Schema = mongoose.Schema



const UserSchema = new Schema({
    name: {
        type: String,
        require: true
    },
    email: {
        type: String,
        required: true,
        match: /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/
    },
    phonenumber: {
        type: String
    },
    HighestDegree: {
        type: String
    },
    Gender: {
        type: String
    },
    parentname: {
        type: String
    },
    parentPhone: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    isActive: {
        type: Number
    },
    createdAt: {
        type: Date,
        required: true,
        default: Date.now
    }
});

module.exports = mongoose.model("users", UserSchema)