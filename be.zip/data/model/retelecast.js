const mongoose = require('mongoose')
const Schema = mongoose.Schema



const RetelecastSchema = new Schema({
    name: {
        type: String,
     
    },
    board: {
        type: String,        
    },
    email: {
        type: String,
   
        // match: /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/
    },
    phonenumber: {
        type: String,
        unique:true
    },
    HighestDegree: {
        type: String
    },
    gender: {
        type: String
    },
    parentName: {
        type: String
    },
    parentPhone: {
        type: String
    },
    partiattending: {
        type: String
    },
    parti: {
        type: String
    },
    school: {
        type: String
    },
    dob: {
        type: String
    },
    stream:{
        type: String
    },
    collegename: {
        type: String
    },
    otp: {
        type: String
    },
    state: {
        type: String
    },
    city: {
        type: String
    },
    mode:{
        type: String
    },
    address:{
        type: String
    },
    OrderId:{
        type:String
    },
    date: {
        type: String,
        
    },
    createdAt: {
        type: Date,
      
        default: Date.now
    },
    reference:{
        type:String
    },
    isActive:{
        type:String
    }
});

module.exports = mongoose.model("retelecasts", RetelecastSchema)