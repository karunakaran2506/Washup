const express = require('express')
const router = express.Router();

const OrderController = require('../controller/OrderController')
const OnetoOneController = require('../controller/OnetoOneController')
const LimitedController = require('../controller/LimitedController')
const UnlimitedController = require('../controller/UnlimitedController')
const RazorpayController = require('../controller/RazorpayController')
const AdminController = require('../controller/AdminController')
const retelecastController = require('../controller/retelecastController')



//Admin
router.post('/adminRegister', AdminController.adminRegister)
router.post('/adminLogin', AdminController.adminLogin)
router.get('/adminViewProfile', AdminController.adminViewProfile)



//Orders
router.post('/addOrder', OrderController.addOrder)
router.post('/viewOrder', OrderController.viewOrder)
router.post('/viewOrderbyId', OrderController.viewOrderbyId)
router.get('/getCapturedOnetoOneBookingCount', OrderController.getCapturedOnetoOneBookingCount)
router.get('/getUncapturedOnetoOneBookingCount', OrderController.getUncapturedOnetoOneBookingCount)
router.get('/getCapturedLimitedBookingCount', OrderController.getCapturedLimitedBookingCount)
router.get('/getUncapturedLimitedBookingCount', OrderController.getUncapturedLimitedBookingCount)



//One-to-One
router.post('/addOnetoOneMeet', OnetoOneController.addOnetoOneMeet)
router.post('/viewOnetoOneMeet', OnetoOneController.viewOnetoOneMeet)
router.post('/viewOnetoOneMeetbyId', OnetoOneController.viewOnetoOneMeetbyId)
router.post('/OnetoOneMeetupdateCount', OnetoOneController.OnetoOneMeetupdateCount)
router.post('/viewOnetoOneMeetbyDate', OnetoOneController.viewOnetoOneMeetbyDate)

//Limited
router.post('/addLimitedMeet', LimitedController.addLimitedMeet)
router.post('/viewLimitedMeet', LimitedController.viewLimitedMeet)
router.post('/viewLimitedMeetbyId', LimitedController.viewLimitedMeetbyId)
router.post('/LimitedMeetupdateCount', LimitedController.LimitedMeetupdateCount)
router.post('/viewLimitedMeetbyDate', LimitedController.viewLimitedMeetbyDate)

//Unimited
router.post('/addUnlimitedMeet', UnlimitedController.addUnlimitedMeet)
router.post('/viewUnlimitedMeet', UnlimitedController.viewUnlimitedMeet)
router.post('/viewUnlimitedMeetbyId', UnlimitedController.viewUnlimitedMeetbyId)
router.post('/UnlimitedMeetupdateCount', UnlimitedController.UnlimitedMeetupdateCount)
router.post('/addUnlimitedOrder', UnlimitedController.addUnlimitedOrder)
router.post('/addUnlimitedOrderMobile', UnlimitedController.addUnlimitedOrderMobile)
router.get('/viewUnlimitedBookings', UnlimitedController.viewUnlimitedBookings)
router.get('/getUnlimitedBookingCount', UnlimitedController.getUnlimitedBookingCount)
router.post('/addUnlimitedOrderOtp', UnlimitedController.addUnlimitedOrderOtp)
router.post('/userVerifyOtp', UnlimitedController.userVerifyOtp)
router.post('/userResendOtp', UnlimitedController.userResendOtp)

router.get('/getUnlimited11thsbBookingCount', UnlimitedController.getUnlimited11thsbBookingCount)
router.get('/getUnlimited11thCbscBookingCount', UnlimitedController.getUnlimited11thCbscBookingCount)


router.get('/getUnlimited12thsbBookingCountstudying', UnlimitedController.getUnlimited12thsbBookingCountstudying)
router.get('/getUnlimited12thCbscBookingCountstudying', UnlimitedController.getUnlimited12thCbscBookingCountstudying)

router.get('/getUnlimitedCollegeBookingCountstudying', UnlimitedController.getUnlimitedCollegeBookingCountstudying)


router.get('/getUnlimited12thCbscBookingCountCompleted', UnlimitedController.getUnlimited12thCbscBookingCountCompleted)
router.get('/getUnlimited12thSbBookingCountComplted', UnlimitedController.getUnlimited12thSbBookingCountComplted)

router.get('/getUnlimitedOthersBookingCount', UnlimitedController.getUnlimitedOthersBookingCount)


// router.get('/sendOtp', UnlimitedController.sendOtp)

router.post('/userVerifyOtp', UnlimitedController.userVerifyOtp)
router.post('/addUnlimitedOrderOtp', UnlimitedController.addUnlimitedOrderOtp)



//razorpay
router.post('/razorpay', RazorpayController.razorpay)
router.post('/razorpay_verification', RazorpayController.razorpay_verification)
router.post('/updateOrderStatus', RazorpayController.updateOrderStatus)

router.post('/addUnlimitedOrderretelecast', retelecastController.addUnlimitedOrderretelecast)





module.exports = router