const Admin = require('../model/admin')
const jwt = require('jsonwebtoken')
const secret = 'supersecret';
var otpGenerator = require('otp-generator')
const bcrypt = require('bcryptjs');
const salt = bcrypt.genSaltSync(8)


const adminRegister = async function (req, res) {
    let promise = new Promise(async function (resolve, reject) {
        try {
            let hashedPassword = bcrypt.hashSync(req.body.password, salt)
            let register = await Admin.create({
                name: req.body.name,
                email: req.body.email,
                password: hashedPassword
            }).then((data) => {
                resolve({ success: true, message: 'admin registered successfully' });
                console.log('succeess');
            })
        } catch (error) {
            reject({ success: false, message: "failed", error })
            console.log(error);
        }
    });

    promise.then(function (data) {
        res.send({ success: data.success, message: data.message })

    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : 'error occured', error: error })


    })
}


const adminLogin = async function (req, res) {
    let isValidparams = req.body.email && req.body.password
    let promise = new Promise(async function (resolve, reject) {
        try {
            if (isValidparams) {
                let adminId = await Admin.findOne({ email: req.body.email })
                console.log('check', adminId)
                if (adminId) {
                    let passwordIsValid = await bcrypt.compareSync(req.body.password, adminId.password)
                    if (passwordIsValid) {
                        console.log('Password Is Valid', passwordIsValid);
                        let token = await jwt.sign({ _id: adminId._id }, secret, { expiresIn: '30d' })
                        console.log('token', token);
                        resolve({ success: true, message: "Password Is Valid", token: token })
                    } else {
                        reject({ success: false, message: "Password Is Invalid" })
                    }

                    // if (!passwordIsValid) {
                    //     reject({ success: false, message: "Check Your Password" })
                    // }

                } else {
                    reject({ success: false, message: "EmailId Not Found" })
                }
            } else {
                reject({ success: false, message: "Required Params" })
            }
        } catch (error) {
            reject({ success: false, message: "Errror Occured While Creating", error: error })
            console.log(error)
        }
    });

    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, token: data.token })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : 'Error occured while Create customer', error: error });
    })

}


const adminViewProfile = async function (req, res) {
    isValidtoken = req.headers.token
    let promise = new Promise(async function (resolve, reject) {
        try {
            if (isValidtoken) {
                let adminId = jwt.verify(req.headers.token, secret)
                console.log('adminId', adminId)
                let checkAdmin = await Admin.findOne({ _id: adminId._id })
                console.log(checkAdmin)
                if (checkAdmin) {
                    resolve({ success: true, message: "List of data", admin: checkAdmin })
                } else {
                    reject({ success: false, message: "Admin Not Found" })
                }

            } else {
                reject({ success: false, message: 'Required Token' })
            }
        } catch (error) {
            reject({ success: false, message: 'Error occured while getting userData', error: error })
            console.log(error);

        }
    });
    promise.
        then(function (data) {
            console.log('success')
            res.send({ success: data.success, message: data.message, admin: data.admin });

        }).catch(function (error) {
            console.log('Inside catch', error)
            res.send({ success: error ? error.success : false, message: error ? error.message : 'Error occured while getting data' });
        });
}




module.exports = {
    adminRegister,
    adminLogin,
    adminViewProfile
}