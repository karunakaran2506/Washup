const User = require('../model/user')
var nodemailer = require('nodemailer')