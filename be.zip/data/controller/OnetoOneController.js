const OnetoOne = require('../model/onetone')


const addOnetoOneMeet = async function (req, res) {
    console.log("first")
    console.log("addMeet",req.body)
            // let isValidtoken = req.headers.token
    let promise = new Promise(async function (resolve, reject) {
        try {
            console.log("test")
            var date=new Date(req.body.date)
            console.log("date",date.toString())
            console.log("day",date.toString().split(' ')[0])

                                    // if (isValidtoken) {
            //     let adminId = jwt.verify(req.headers.token, secret)
            //     console.log("test1", adminId)
            //     let checkAdmin = await Admin.findOne({ _id: adminId._id })
            //     console.log("test2", checkAdmin)
            //     if (checkAdmin) {
                    let addMeet = await OnetoOne.create({
                        date:req.body.date,
                        dateString:req.body.dateString,
                        timing:req.body.timing,
                        Amount:req.body.Amount,
                        day:date.toString().split(' ')[0]
                    })
                    console.log("Meet Details",addMeet)
                    if(addMeet){
                    // console.log(addMeet)
                    resolve({ success: true, message: "Meet created" , meet:addMeet})
                }                
                else{
                    reject({ success: false, message: "Meet not Created" })
                }
                                            // } else {
                //     reject({ success: false, message: 'Admin ID Invalid' })
                // }
            // } else {
            //     reject({ success: false, message: "Token Invalid" })
            // }

        } catch (error) {
            reject({ success: false, message: "Please Fill all the fields", error: error })
            console.log("error",error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message ,meet:data.meet})
    }).catch(function (error) {
        res.send({ success: error.success, message: error.message, error: error })
    })
}
const viewOnetoOneMeet = async function (req, res) {
    var recentDate = new Date().getTime();
    console.log("today",recentDate.toString())
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await OnetoOne.find({'date':{$gte:recentDate}})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const viewOnetoOneMeetbyId = async function (req, res) {

let promise = new Promise(async function (resolve, reject) {
    try {

        let viewMeet = await OnetoOne.findOne({_id:req.body.id})
        resolve({ success: true, userMeet: viewMeet })

    } catch (error) {
        reject({ success: false, message: "Error Occured while Listing Data", error: error })
        console.log(error)
    }
});
promise.then(function (data) {
    res.send({ success: data.success, message: data.message, meet: data.userMeet })
}).catch(function (error) {
    res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

})
}

const viewOnetoOneMeetbyDate = async function (req, res) {

    let promise = new Promise(async function (resolve, reject) {
        try {
    
            let viewMeet = await OnetoOne.findOne({date:req.body.date})
            resolve({ success: true, userMeet: viewMeet })
    
        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.userMeet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })
    
    })
    }
const OnetoOneMeetupdateCount = async function (req, res) {

    let promise = new Promise(async function (resolve, reject) {
        try {
    
            let viewMeet = await OnetoOne.findOne({date:req.body.date})
            if(viewMeet){
                let update = await OnetoOne.updateOne({date:viewMeet.date},{
                    $inc:{
                        currentUser : 1
                    }
                })
                if(update)
                    resolve({ success: true, userMeet: update })
            }
            
    
        } catch (error) {
            reject({ success: false, message: "Error Occured while Updating Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.userMeet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Updating Data", error: error })
    
    })
    }

module.exports={
    addOnetoOneMeet,
    viewOnetoOneMeet,
    viewOnetoOneMeetbyId,
    OnetoOneMeetupdateCount,
    viewOnetoOneMeetbyDate
}