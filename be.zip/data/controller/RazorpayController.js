const Razorpay = require('razorpay');
const nodemailer = require('nodemailer')
const Order = require('../model/bookings');

var OrderStatus;
//Change in razorpay function as well
const rzp_key = 'rzp_live_3kWDlBKtn7TJw7'
const rzp_secret = 'AxUGcg1SurnUTQw5mrhD3Rqd'
var razorpay_ksa = new Razorpay({
    key_id: rzp_key, //Subject to Change
    key_secret: rzp_secret
  })

  const razorpay = async function (req, res) {
    // let isValidParams = req.headers.token
    //var razorpayOrder 
    let promise = new Promise(async function (resolve, reject) {
        try {

                console.log("razorpay body",req.body)
                    var amount = req.body.amount * 100;
                    console.log("Actual Amount",parseInt(amount) );
                    //var password = "ljE6gr2HX9djZrscyS3hQx1W";
                    var options = {
                        amount: parseInt(amount),
                        currency:"INR",
                        receipt:"order_rcptid_11"
                    }
                    var razorpayOrderId;

                    await razorpay_ksa.orders.create(options, function(err, order) {
                        console.log("razorpayOrder",order);
                        razorpayOrderId = order.id
                    });


                    let obj = {
                        key: rzp_key,
                        currency: "INR",
                        order_id: razorpayOrderId,
                        amount: amount,//amount
                    };
                    resolve({ success: true, razorpay: obj })
                
        } catch (e) {
            console.log('Error in getting razorpay', e)
            reject({ success: false, message: 'Error occured while Razorpay', error: e })
        }
    });

    promise.
        then(function (data) {
            console.log('Razorpay Inside then')
            res.send({ success: data.success, razorpay: data.razorpay });

        }).catch(function (error) {
            console.log('Inside catch', error)
            res.send({ success: error ? error.success : false, message: error ? error.message : 'Error occured while getting razorpay' });
        });
}

const razorpay_verification = async function (req, res) {//orderId,razorpay_payment_id,razorpay_order_id

    console.log("razorpayverifybody",req.body)
    let promise = new Promise(async function (resolve, reject) {
        try {

                    let getOrder = await Order.findOne({OrderId: req.body.orderId})
                    const options1 = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                    const date1 = new Date(getOrder.date);
                    const dateTimeFormat = new Intl.DateTimeFormat('en-US', options1);
                    var date = dateTimeFormat.format(date1)
                    console.log("getOrder",getOrder)
                    if(getOrder){
                    let updateOrder = await Order.updateOne({ OrderId: req.body.orderId }, {
                        $set: {
                            razorpayPaymentId: req.body.razorpay_payment_id,
                            razorpayOrderId: req.body.razorpay_order_id
                        }
                    })
                    console.log("updateOrder",updateOrder)
                    if(updateOrder){
                        var transporter = nodemailer.createTransport({
                            service: 'gmail',
                            auth: {
                                user: 'noreply@ksacademy.co.in',
                                pass: 'Ksa@2311'
                            }
                        });

                        if(getOrder.ccmeet=="1to1")
                        {
                            var mailOptions = {
                                from: 'KS ACADEMY noreply@ksacademy.co.in',
                                to: getOrder.email,
    
                                subject: 'Greetings from KS Academy!',
                                
                              
                                html: `<!DOCTYPE html>
                                <html>
                                <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                
                                    <title>Greetings from KS Academy!</title>
                                
                                    <style>
                                
                                        body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                
                                    </style>
                                
                                    <style>
                                        .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                            !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                @media screen and (max-width:600px) {
                                                    table[class="columns"] {
                                                        margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                    }
                                                    td[class="left"] {
                                                        padding: 0px 0 !important;
                                                    </style>
                                
                                                </head>
                                
                                                <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                
                                                    <style type="text/css">
                                                        div.preheader 
                                                        { display: none !important; } 
                                                    </style>
                                                    <div class="preheader" style="font-size: 1px; display: none !important;">Mute videos until you’re ready</div>
                                                    <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                        <tr>
                                                            <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                <table cellpadding="0" cellspacing="0">
                                                                    <tr>
                                                                        <td width="640">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                <tr>
                                                                                    <td width="640" align="left">
                                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                    <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="KSA" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table></td></tr></table>
                                
                                
                                
                                
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td style="padding-bottom: 20px;">
                                                                <table cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td class="featured-story__inner" style="background: #fff;">
                                                                            <table cellspacing="0" cellpadding="0">
                                                                                
                                                                                <tr>
                                                                                    <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Dear ${getOrder.name},
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                        <tr>
                                                                                                        <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                        Reference ID : ${getOrder.OrderId},
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                                Greetings from KS Academy!<br>
                                                                                                            
                                                                                                                We acknowledge your registration with KS Academy for KSA One-to-One Career Counselling Meet 2022.<br>
                                                                                               
                                                                                                                 CCM Date: ${date} <br>
                                                                                                                 Timing: 07:30 PM
                                                                                                                 Mode: Online (Zoom Meeting)<br>
    
                                                                                                                 Zoom Link and other instructions will be sent via mail a day before!<br>
    
                                                                                                                 For any queries, Contact - 988 433 6666 <br>
    
    
                                                                                                                 Thanks & Regards,<br>
                                                                                                                 Team KSA<br>			
                                                                                                              
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                    <a href="https://ksacademy.co.in/">
                                                                                                        Visit website for more details
                                                                                                    </a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table></td></tr></table></td>
                                                                        </tr>
                                
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                
                                                        <!-- Exact Target tracking code -->
                                
                                
                                                    </custom></body>
                                                    </html>`
                            };
                        }
                        else{



                            var mailOptions = {
                                from: 'KS ACADEMY noreply@ksacademy.co.in',
                                to: getOrder.email,
    
                                subject: 'Greetings from KS Academy!',
                                
                              
                                html: `<!DOCTYPE html>
                                <html>
                                <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                
                                    <title>Greetings from KS Academy!</title>
                                
                                    <style>
                                
                                        body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                
                                    </style>
                                
                                    <style>
                                        .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                            !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                @media screen and (max-width:600px) {
                                                    table[class="columns"] {
                                                        margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                    }
                                                    td[class="left"] {
                                                        padding: 0px 0 !important;
                                                    </style>
                                
                                                </head>
                                
                                                <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                
                                                    <style type="text/css">
                                                        div.preheader 
                                                        { display: none !important; } 
                                                    </style>
                                                    <div class="preheader" style="font-size: 1px; display: none !important;">Mute videos until you’re ready</div>
                                                    <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                        <tr>
                                                            <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                <table cellpadding="0" cellspacing="0">
                                                                    <tr>
                                                                        <td width="640">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                <tr>
                                                                                    <td width="640" align="left">
                                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                    <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="KSA" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table></td></tr></table>
                                
                                
                                
                                
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td style="padding-bottom: 20px;">
                                                                <table cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td class="featured-story__inner" style="background: #fff;">
                                                                            <table cellspacing="0" cellpadding="0">
                                                                                
                                                                                <tr>
                                                                                    <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Dear ${getOrder.name},
                                                                                                            </td>
                                                                                                        </tr>

                                                                                                        <tr>
                                                                                                        <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                        Reference ID : ${getOrder.OrderId},
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                                Greetings from KS Academy!<br>
                                                                                                            
                                                                                                               
We acknowledge your registration with KS Academy for KSA Group Career Counselling Meet 2022. <br>

CCM Selected Date: ${date}<br>
Timing: 10:30 AM<br>
Mode: Online (Zoom Meeting)<br>

Zoom Link and other instructions will be sent via mail a day before!<br>

For any queries, Contact - 988 433 6666, 			<br>
                                  
Thanks  & Regards,<br>
Team KSA  <br>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                    <a href="https://ksacademy.co.in/">
                                                                                                        Visit website for more details
                                                                                                    </a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table></td></tr></table></td>
                                                                        </tr>
                                
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                
                                                        <!-- Exact Target tracking code -->
                                
                                
                                                    </custom></body>
                                                    </html>`
                            };
                        }
                       
                        transporter.sendMail(mailOptions, function (error, info) {
                            if (error) {
                                console.log(error);
                            } else {
                                console.log('email sent:' + info.res);
                            }
                        });
                    resolve({ success: true, message: 'Razorpay details were updated successfully',razorpay_order_id: req.body.razorpay_order_id })
                    }
                    else{
                        reject({ success: false, message: "Razorpay Order Status Not updated" })
                    }
                }else{
                    reject({ success: false, message: "Meeting Not Booked" })
                }
        } catch (e) {
            console.log('Error in player_id', e)
            reject({ success: false, message: 'Error occured while updating razorpay details', error: e })
        }
    });

    promise.
        then(function (data) {
            console.log('Inside then')
            res.send({ success: data.success, message: data.message, razorpay_order_id: data.razorpay_order_id });

        }).catch(function (error) {
            console.log('Inside catch', error)
            res.send({ success: error ? error.success : false, message: error ? error.message : 'Error occured while updating razorpay details' });
        });
}


const updateOrderStatus= async function(req,res){//razorpay_order_id
      let promise = new Promise(async function (resolve, reject) {
        try {
                let razorpay_order_id = req.body.razorpay_order_id
                let checkOrder = await Order.findOne({razorpayOrderId:razorpay_order_id })
                // console.log("checkVertical.verticalName",checkOrder)
                await razorpay_ksa.orders.fetchPayments(razorpay_order_id, function(err, order) {
                    console.log("responseOrderStatus",order);
                    this.OrderStatus=order.items[0].status
                })

                console.log("OrderStatus",this.OrderStatus)
                let razorpayUpdate = await Order.updateOne({razorpayOrderId : razorpay_order_id},{
                    $set:{
                        status : this.OrderStatus
                    }
                    
                })
                if(razorpayUpdate)
                    resolve({ success: true, message: "Order Status Updated Succesfully" })
                else
                    reject({ success: false, message: "Order Status Not Updated " })


        } catch (error) {
            reject({ success: false, message: "error occured while Updating Status", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "error occured while Updating Status", error: error })
    })
}


module.exports={
razorpay,
razorpay_verification,
updateOrderStatus
}