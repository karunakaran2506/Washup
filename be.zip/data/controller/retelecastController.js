const Booking = require('../model/retelecast')
const nodemailer = require('nodemailer')
var otpGenerator = require('otp-generator')

const SendOtp = require('sendotp');
const msg91AUth = '353575Aujzp6B1f3t601e1e11P1'
const sendOtp = new SendOtp(msg91AUth);

const fetch = require('node-fetch');


var http = require("https");

const addUnlimitedMeet = async function (req, res) {
    console.log("first")
    console.log("addMeet",req.body)
            // let isValidtoken = req.headers.token
    let promise = new Promise(async function (resolve, reject) {
        try {
            console.log("test")
                                    // if (isValidtoken) {
            //     let adminId = jwt.verify(req.headers.token, secret)
            //     console.log("test1", adminId)
            //     let checkAdmin = await Admin.findOne({ _id: adminId._id })
            //     console.log("test2", checkAdmin)
            //     if (checkAdmin) {
                    let addMeet = await Unlimited.create({
                        date:req.body.date,
                        timing:req.body.timing
                    })
                    console.log("Meet Details",addMeet)
                    if(addMeet){
                    // console.log(addMeet)
                    resolve({ success: true, message: "Meet created" , meet:addMeet})
                }                
                else{
                    reject({ success: false, message: "Meet not Created" })
                }
                                            // } else {
                //     reject({ success: false, message: 'Admin ID Invalid' })
                // }
            // } else {
            //     reject({ success: false, message: "Token Invalid" })
            // }

        } catch (error) {
            reject({ success: false, message: "Please Fill all the fields", error: error })
            console.log("error",error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message ,meet:data.meet})
    }).catch(function (error) {
        res.send({ success: error.success, message: error.message, error: error })
    })
}
const viewUnlimitedMeet = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Unlimited.find({'date':{$gte :recentDate}})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const viewUnlimitedMeetbyId = async function (req, res) {

let promise = new Promise(async function (resolve, reject) {
    try {

        let viewMeet = await Unlimited.findOne({_id:req.body.id})
        resolve({ success: true, userMeet: viewMeet })

    } catch (error) {
        reject({ success: false, message: "Error Occured while Listing Data", error: error })
        console.log(error)
    }
});
promise.then(function (data) {
    res.send({ success: data.success, message: data.message, meet: data.userMeet })
}).catch(function (error) {
    res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

})
}
const UnlimitedMeetupdateCount = async function (req, res) {

    let promise = new Promise(async function (resolve, reject) {
        try {
    
            let viewMeet = await Unlimited.findOne({_id:req.body.id})
            if(viewMeet){
                let update = await Unlimited.updateOne({_id:viewMeet._id},{
                    $inc:{
                        currentUser : 1
                    }
                })
                if(update)
                    resolve({ success: true, userMeet: update })
            }
            
    
        } catch (error) {
            reject({ success: false, message: "Error Occured while Updating Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.userMeet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Updating Data", error: error })
    
    })
    }



    const addUnlimitedOrderOtp = async function (req, res) {
        let isValidparams = req.body.email && req.body.phonenumber
        let promise = new Promise(async function (resolve, reject) {
            try {
                
                let otp = otpGenerator.generate(8, { upperCase: false, specialChars: false, alphabets: false })
                    let orderNo =  otp;                
                if (isValidparams) {

                //     let viewMeet = await Booking.findOne({phonenumber:req.body.phonenumber})

                //   if(viewMeet.phonenumber==req.body.phonenumber){
                //     reject({ success: false, message: "User already Registred" })
                //   }
                //   else{                      
                    
                    let email = req.body.email;
                    let phonenumber = req.body.phonenumber
                    let otp = otpGenerator.generate(4, { upperCase: false, specialChars: false, alphabets: false })
                    console.log(otp);
                    let userRetry=await Booking.findOne({email: req.body.email, phonenumber: req.body.phonenumber, isActive:0});
                    let userExist=await Booking.findOne({email: req.body.email, phonenumber: req.body.phonenumber, isActive:1});
                    if(userRetry){
                    const sendOtp = new SendOtp(msg91AUth, 'Dear Students, Your OTP is {{otp}}. Use this passcode to complete your transaction. Thank you. please do not share it with anybody');

                        //sendOtp.setOtpExpiry('15');//Expires in 15 Mins
                        await sendOtp.send("91"+phonenumber, "KSA CCMEET", otp, function (error, data) {
                            console.log("91"+phonenumber,data);
                            if(error){
                                console.log(error);
                            }
                          });
                        await Booking.updateOne({ email: req.body.email }, {
                            $set: {
                                name:req.body.name,
                                board:req.body.board,
                                email:req.body.email,
                                phonenumber:req.body.phonenumber,
                                HighestDegree:req.body.HighestDegree,
                                gender:req.body.gender,
                                parentName:req.body.parentName,
                                parentPhone:req.body.parentPhone,
                                OrderId: '',
                                city:req.body.city,
                                state:req.body.state,
                                address:req.body.address,
                                reference:req.body.reference,
                                partiattending:req.body.partiattending,
                                parti:req.body.parti,
                                school:req.body.school,
                                dob:req.body.dob,
                                collegename:req.body.collegename,
                                stream:req.body.stream,
                                mode:req.body.mode,
                                isActive:0,
                                otp: otp
                                }
                        })
                        console.log("Existing User")
                        resolve({ success: true, message: "otp sent to phonenumber",register:phonenumber})
                    }
                    else if(userExist){
                        reject({ success: false, message: "User Already Registered" })
                    }
                    else{
                    const sendOtp = new SendOtp(msg91AUth, 'Dear Students, Your OTP is {{otp}}. Use this passcode to complete your transaction. Thank you. please do not share it with anybody');
                    console.log("91"+phonenumber);
                    await sendOtp.send("91"+phonenumber, "KSA-CCMEET", otp, function (error, data , info) {
                        console.log(data);
                        console.log("otp Sent")
                        if(error){
                            console.log(error);
                        }
                      });
                        await Booking.create({
                            name:req.body.name,
                            board:req.body.board,
                            email:req.body.email,
                            phonenumber:req.body.phonenumber,
                            HighestDegree:req.body.HighestDegree,
                            gender:req.body.gender,
                            parentName:req.body.parentName,
                            parentPhone:req.body.parentPhone,
                            OrderId: '',
                            city:req.body.city,
                            state:req.body.state,
                            address:req.body.address,
                            reference:req.body.reference,
                            partiattending:req.body.partiattending,
                            parti:req.body.parti,
                            school:req.body.collegename,
                            dob:req.body.dob,
                            collegename:req.body.collegename,
                            stream:req.body.stream,
                            mode:req.body.mode,
                            isActive:0,   
                            otp: otp                       
                        })
                        console.log("New User")
                        
                        // await Booking.updateOne({ email: req.body.email }, {
                        //     $set: {
                        //         otp: otp
                        //     }
                        // })
                  }
                  console.log({ otp: otp })
                  console.log({ email:  req.body.email })
                  resolve({ success: true, message: "otp sent to phonenumber",register:phonenumber})
                //    }

    
                } else {
                    reject({ success: false, message: "Please provide Email and Phonenumber" })
    
                }
            } catch (error) {
                reject({ success: false, message: "error occured while register", error: error })
                console.log(error);
            }
        });
        promise.then(function (data) {
            res.send({ success: data.success, message: data.message, data: data.register })
    
        }).catch(function (error) {
            res.send({ success: error ? error.success : false, message: error ? error.message : 'error occured', error: error })
        })
    
    }



    const userVerifyOtp = async function (req, res) {
        // let isValidParams = req.body.otp

        console.log("phone",req.body.phonenumber)
        console.log("otp",req.body.otp)

        console.log('otpRequest', req.body)
        let promise = new Promise(async function (resolve, reject) {
            try {
                let checkUser = await Booking.findOne({phonenumber: req.body.phonenumber })
                console.log("try object",checkUser)
                if (checkUser) {
                    console.log("checkUser object",checkUser)  
                    
                    let verify = await sendOtp.verify("91"+checkUser.phonenumber, req.body.otp, async function (error, data) {
                        console.log(data); // data object with keys 'message' and 'type'
                        if(data.type == 'success'){ 
                            console.log('OTP verified successfully')

                            let otp = otpGenerator.generate(8, { upperCase: false, specialChars: false, alphabets: false })
                            let orderNo =  otp;  
    
                           console.log("hlo")
                            await Booking.updateOne({ phonenumber: req.body.phonenumber }, {
                                $set: {
                                    isActive: '1',
                                    OrderId: orderNo,
                                }
                            })
                            var transporter = nodemailer.createTransport({
                                service: 'gmail',
                                auth: {
                                    user: 'noreply@ksacademy.co.in',
                                    pass: 'Ksa@2311'
                                }
                            });
                            if(req.body.mode == 'Online'){
                                var mailOptions = {
                                    from: 'KS ACADEMY noreply@ksacademy.co.in',
                                    to: req.body.email,
                                    subject: 'KSA ACADEMY - MEET REGISTRATION',
                                    html: `<!DOCTYPE html>
                                    <html>
                                    <head>
                                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                    
                                        <title>Welcome to KS Academy </title>
                                    
                                        <style>
                                    
                                            body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                    
                                        </style>
                                    
                                        <style>
                                            .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                                !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                    !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                    @media screen and (max-width:600px) {
                                                        table[class="columns"] {
                                                            margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                        }
                                                        td[class="left"] {
                                                            padding: 0px 0 !important;
                                                        </style>
                                    
                                                    </head>
                                    
                                                    <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                    
                                                        <style type="text/css">
                                                            div.preheader 
                                                            { display: none !important; } 
                                                        </style>
                                                        <div class="preheader" style="font-size: 1px; display: none !important;"></div>
                                                        <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                            <tr>
                                                                <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                    <table cellpadding="0" cellspacing="0">
                                                                        <tr>
                                                                            <td width="640">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                                <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                    <tr>
                                                                                        <td width="640" align="left">
                                                                                            <table width="100%" cellspacing="0" cellpadding="0">
                                                                                                <tr>
                                                                                                    <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                        <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table></td></tr></table>
                                    
                                    
                                    
                                    
                                                                                <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                            <tr>
                                                                <td style="padding-bottom: 20px;">
                                                                    <table cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td class="featured-story__inner" style="background: #fff;">
                                                                                <table cellspacing="0" cellpadding="0">
                                                                                    
                                                                                    <tr>
                                                                                        <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                            <table cellspacing="0" cellpadding="0">
                                                                                                <tr>
                                                                                                    <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                                            <tr>
                                                                                                                <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                                Dear ${req.body.name},
                                                                                                                </td>
                                                                                                            </tr> 
        
                                                                                                            <tr>
                                                                                                                <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                                Reference ID : ${orderNo}
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                                            <tr>
                                                                                                                <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                                We acknowledge your registration with KS Academy for KSA FREE Mega Career Counselling Meet 2022.<br>
        
                                                                                                                CCM Selected Date: January 30, 2022 (Sunday)<br>
                                                                                                                Timing: 10:30 AM<br>
                                                                                                                Mode: Online (Zoom Meeting)<br>
                                                                                                                
                                                                                                                Zoom Link and other instructions will be sent via mail a day before!
                                                                                                                
                                                                                                                For any queries, Contact - 988 433 6666, <br>	
                                                                                                                
                                                                                                                Thanks & Regards,<br>
                                                                                                                Team KSA<br>
                                                                                                                   <br>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                        <a href="https://ksacademy.co.in/">
                                                                                                            Visit website for more details
                                                                                                        </a>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table></td></tr></table></td>
                                                                            </tr>
                                    
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                    
                                                            <!-- Exact Target tracking code -->
                                    
                                    
                                                        </custom></body>
                                                        </html>`
                                };
                            }
                            else{
                                var mailOptions = {
                                    from: 'KS ACADEMY noreply@ksacademy.co.in',
                                    to: req.body.email,
                                    subject: 'KSA ACADEMY - MEET REGISTRATION',
                                    html: `<!DOCTYPE html>
                                    <html>
                                    <head>
                                        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                    
                                        <title>Welcome to KS Academy </title>
                                    
                                        <style>
                                    
                                            body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                    
                                        </style>
                                    
                                        <style>
                                            .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                                !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                    !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                    @media screen and (max-width:600px) {
                                                        table[class="columns"] {
                                                            margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                        }
                                                        td[class="left"] {
                                                            padding: 0px 0 !important;
                                                        </style>
                                    
                                                    </head>
                                    
                                                    <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                    
                                                        <style type="text/css">
                                                            div.preheader 
                                                            { display: none !important; } 
                                                        </style>
                                                        <div class="preheader" style="font-size: 1px; display: none !important;"></div>
                                                        <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                            <tr>
                                                                <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                    <table cellpadding="0" cellspacing="0">
                                                                        <tr>
                                                                            <td width="640">
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                                <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                    <tr>
                                                                                        <td width="640" align="left">
                                                                                            <table width="100%" cellspacing="0" cellpadding="0">
                                                                                                <tr>
                                                                                                    <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                        <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table></td></tr></table>
                                    
                                    
                                    
                                    
                                                                                <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                            <tr>
                                                                <td style="padding-bottom: 20px;">
                                                                    <table cellspacing="0" cellpadding="0">
                                                                        <tr>
                                                                            <td class="featured-story__inner" style="background: #fff;">
                                                                                <table cellspacing="0" cellpadding="0">
                                                                                    
                                                                                    <tr>
                                                                                        <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                            <table cellspacing="0" cellpadding="0">
                                                                                                <tr>
                                                                                                    <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                                            <tr>
                                                                                                                <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                                Dear ${req.body.name},
                                                                                                                </td>
                                                                                                            </tr> 
        
                                                                                                            <tr>
                                                                                                                <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                                Reference ID : ${orderNo}
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                                            <tr>
                                                                                                                <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                                We acknowledge your registration with KS Academy for KSA FREE Mega Career Counselling Meet 2022.<br>
        
                                                                                                                CCM Selected Date: January 30, 2022 (Sunday)<br>
                                                                                                                Timing: 10:30 PM<br>
                                                                                                                Mode: Offline<br>                                                                                                            
                                                                                                                For any queries, Contact - 988 433 6666, <br>	\                                                                                                            
                                                                                                                Thanks & Regards,<br>
                                                                                                                Team KSA<br>
                                                                                                                   <br>
                                                                                                                </td>
                                                                                                            </tr>
                                                                                                        </table>
                                                                                                    </td>
                                                                                                </tr>
                                                                                                <tr>
                                                                                                    <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                        <a href="https://ksacademy.co.in/">
                                                                                                            Visit website for more details
                                                                                                        </a>
                                                                                                    </td>
                                                                                                </tr>
                                                                                            </table>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table></td></tr></table></td>
                                                                            </tr>
                                    
                                                                        </table>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                    
                                                            <!-- Exact Target tracking code -->
                                    
                                    
                                                        </custom></body>
                                                        </html>`
                                };
                            }
                                                    
                            
                          
                            transporter.sendMail(mailOptions, function (error, info) {
                                if (error) {
                                    console.log(error);
                                } else {
                                    console.log('email sent:' + info.res);
                                }
                            });			
                           
                            resolve({ success: true, message: 'valid otp'})

                        }else{
                            console.log('OTP verification failed')
                            reject({ success: false, message: 'Invalid OTP' })
                        }
                    });

                 

                     
                } else {
                    reject({ success: false, message: 'Invalid Phone Number'})
                }
            } catch (error) {
                reject({ success: error ? error.success : false, message: error ? error.message : 'error occured while verify', error: error })
    
            }
        });
        promise.then(function (data) {
            console.log("success")
            res.send({ success: data.success, message: data.message ,data: data.data,token:data.token})
        }).catch(function (error) {
            console.log({ error: error })
            res.send({ success: error ? error.success : false, message: error ? error.message : 'error occured while update', error: error })
    
        })
    }
    
    

    const addUnlimitedOrderretelecast = async function (req, res) {
        console.log("first")
        console.log("addOrder",req.body)
        let promise = new Promise(async function (resolve, reject) {
            try {
                console.log("test")
                    let otp = otpGenerator.generate(8, { upperCase: false, specialChars: false, alphabets: false })
                    let orderNo =  otp;
                    console.log('Order Number', orderNo)
                        console.log('run3')
                        let addOrder = await Booking.create({
                            name:req.body.name,
                            board:req.body.board,
                            email:req.body.email,
                            phonenumber:req.body.phonenumber,                      
                            HighestDegree:req.body.HighestDegree,
                            gender:req.body.gender,
                            parentName:req.body.parentName,
                            parentPhone:req.body.parentPhone,
                            OrderId: orderNo,
                            city:req.body.city,
                            state:req.body.state,
                            address:req.body.address,
                            reference:req.body.reference,
                            partiattending:req.body.partiattending,
                            parti:req.body.parti,
                            school:req.body.collegename,
                            dob:req.body.dob,
                            collegename:req.body.collegename,
                            stream:req.body.stream,
                            mode:req.body.mode,
                            
                        })
                        console.log("order Details",addOrder)
                        if(addOrder){

                        var transporter = nodemailer.createTransport({
                            service: 'gmail',
                            auth: {
                                user: 'noreply@ksacademy.co.in',
                                pass: 'Ksa@2311'
                            }
                        });
                        if(req.body.mode == 'Online'){


   // const response = await fetch('https://sms.viableworlddigital.com/fe/api/v1/send?username=ksacademy1.trans&password=D8KAz&unicode=false&from=KSACMY&to='+req.body.phonenumberotp+'&text=Dear '+req.body.name+', Thank you for registering for KSA Free Mega Career Counselling Meet, Your reference number is - '+orderNo+' You will be receiving the Zoom link through your registered mobile number on Saturday. Thanks and Regards KS Academy&dltContentId=1707162022938953923', {method: 'POST', body: {}});
   // const data = await response.json();



                            var mailOptions = {
                                from: 'KS ACADEMY noreply@ksacademy.co.in',
                                to: req.body.email,
                                subject: 'KS ACADEMY - MEET REGISTRATION',
                                html: `<!DOCTYPE html>
                                <html>
                                <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                
                                    <title>Welcome to KS Academy </title>
                                
                                    <style>
                                
                                        body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                
                                    </style>
                                
                                    <style>
                                        .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                            !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                @media screen and (max-width:600px) {
                                                    table[class="columns"] {
                                                        margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                    }
                                                    td[class="left"] {
                                                        padding: 0px 0 !important;
                                                    </style>
                                
                                                </head>
                                
                                                <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                
                                                    <style type="text/css">
                                                        div.preheader 
                                                        { display: none !important; } 
                                                    </style>
                                                    <div class="preheader" style="font-size: 1px; display: none !important;"></div>
                                                    <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                        <tr>
                                                            <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                <table cellpadding="0" cellspacing="0">
                                                                    <tr>
                                                                        <td width="640">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                <tr>
                                                                                    <td width="640" align="left">
                                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                    <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table></td></tr></table>
                                
                                
                                
                                
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td style="padding-bottom: 20px;">
                                                                <table cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td class="featured-story__inner" style="background: #fff;">
                                                                            <table cellspacing="0" cellpadding="0">
                                                                                
                                                                                <tr>
                                                                                    <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Dear ${req.body.name},
                                                                                                            </td>
                                                                                                        </tr> 
    
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Reference ID : ${orderNo}
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                            We acknowledge your registration with KS Academy for KSA FREE Mega Career Counselling Meet 2022.<br>
    
                                                                                                            CCM Selected Date: January 30, 2022 (Sunday)<br>
                                                                                                            Timing: 10:00 AM<br>
                                                                                                            Mode: Online (Zoom Meeting)<br>
                                                                                                            
                                                                                                            Zoom Link and other instructions will be sent via mail a day before!
                                                                                                            
                                                                                                            For any queries, Contact - 988 433 6666, <br>	
                                                                                                            
                                                                                                            Thanks & Regards,<br>
                                                                                                            Team KSA<br>
                                                                                                               <br>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                    <a href="https://ksacademy.co.in/">
                                                                                                        Visit website for more details
                                                                                                    </a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table></td></tr></table></td>
                                                                        </tr>
                                
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                
                                                        <!-- Exact Target tracking code -->
                                
                                
                                                    </custom></body>
                                                    </html>`
                            };
                        }
                        else{
           //          const response = await fetch('https://sms.viableworlddigital.com/fe/api/v1/send?username=ksacademy1.trans&password=D8KAz&unicode=false&from=KSACMY&to='+req.body.phonenumberotp+'&text=Dear '+req.body.name+', Thank you for registering for KSA Free Mega Career Counselling Meet, Your reference number is - '+orderNo+' You will be receiving the Zoom link through your registered mobile number on Saturday. Thanks and Regards KS Academy&dltContentId=1707162022938953923', {method: 'POST', body: {}});
           // const data = await response.json();
                            var mailOptions = {
                                from: 'KS ACADEMY noreply@ksacademy.co.in',
                                to: req.body.email,
                                subject: 'KS ACADEMY - MEET REGISTRATION',
                                html: `<!DOCTYPE html>
                                <html>
                                <head>
                                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                                
                                    <title>Welcome to KS Academy </title>
                                
                                    <style>
                                
                                        body {margin:0; padding:0; -webkit-text-size-adjust:none; -ms-text-size-adjust:none;} img{line-height:100%; outline:none; text-decoration:none; -ms-interpolation-mode: bicubic;} a img{border: none;} #backgroundTable {margin:0; padding:0; width:100% !important; } a, a:link{color:#2A5DB0; text-decoration: underline;} table td {border-collapse:collapse;} span {color: inherit; border-bottom: none;} span:hover { background-color: transparent; }
                                
                                    </style>
                                
                                    <style>
                                        .scalable-image img{max-width:100% !important;height:auto !important}.button a{transition:background-color .25s, border-color .25s}.button a:hover{background-color:#e1e1e1 !important;border-color:#0976a5 !important}@media only screen and (max-width: 400px){.preheader{font-size:12px !important;text-align:center !important}.header--white{text-align:center}.header--white .header__logo{display:block;margin:0 auto;width:118px !important;height:auto !important}.header--left .header__logo{display:block;width:118px !important;height:auto !important}}@media screen and (-webkit-device-pixel-ratio), screen and (-moz-device-pixel-ratio){.sub-story__image,.sub-story__content{display:block
                                            !important}.sub-story__image{float:left !important;width:200px}.sub-story__content{margin-top:30px !important;margin-left:200px !important}}@media only screen and (max-width: 550px){.sub-story__inner{padding-left:30px !important}.sub-story__image,.sub-story__content{margin:0 auto !important;float:none !important;text-align:center}.sub-story .button{padding-left:0 !important}}@media only screen and (max-width: 400px){.featured-story--top table,.featured-story--top td{text-align:left}.featured-story--top__heading td,.sub-story__heading td{font-size:18px !important}.featured-story--bottom:nth-child(2) .featured-story--bottom__inner{padding-top:10px
                                                !important}.featured-story--bottom__inner{padding-top:20px !important}.featured-story--bottom__heading td{font-size:28px !important;line-height:32px !important}.featured-story__copy td,.sub-story__copy td{font-size:14px !important;line-height:20px !important}.sub-story table,.sub-story td{text-align:center}.sub-story__hero img{width:100px !important;margin:0 auto}}@media only screen and (max-width: 400px){.footer td{font-size:12px !important;line-height:16px !important}}
                                                @media screen and (max-width:600px) {
                                                    table[class="columns"] {
                                                        margin: 0 auto !important;float:none !important;padding:10px 0 !important;
                                                    }
                                                    td[class="left"] {
                                                        padding: 0px 0 !important;
                                                    </style>
                                
                                                </head>
                                
                                                <body style="background: #e1e1e1;font-family:Arial, Helvetica, sans-serif; font-size:1em;">
                                
                                                    <style type="text/css">
                                                        div.preheader 
                                                        { display: none !important; } 
                                                    </style>
                                                    <div class="preheader" style="font-size: 1px; display: none !important;"></div>
                                                    <table id="backgroundTable" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#e1e1e1;">
                                                        <tr>
                                                            <td class="body" align="center" valign="top" style="background:#e1e1e1;" width="100%">
                                                                <table cellpadding="0" cellspacing="0">
                                                                    <tr>
                                                                        <td width="640">
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td class="main" width="640" align="center" style="padding: 0 10px;">
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table cellspacing="0" cellpadding="0">
                                                                                <tr>
                                                                                    <td width="640" align="left">
                                                                                        <table width="100%" cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="header header--left" style="padding: 20px 10px;background: white;" align="center">
                                                                                                    <a href="#" ><img class="header__logo" src="https://ksacademy.co.in/course-registration/assets/img/logos/black-logo.png" alt="" style="display: block; border: 0;" width="158" height="59"></a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table></td></tr></table>
                                
                                
                                
                                
                                                                            <table style="min-width: 100%; " class="stylingblock-content-wrapper" width="100%" cellspacing="0" cellpadding="0"><tr><td class="stylingblock-content-wrapper camarker-inner"><table class="featured-story featured-story--top" cellspacing="0" cellpadding="0">
                                                        <tr>
                                                            <td style="padding-bottom: 20px;">
                                                                <table cellspacing="0" cellpadding="0">
                                                                    <tr>
                                                                        <td class="featured-story__inner" style="background: #fff;">
                                                                            <table cellspacing="0" cellpadding="0">
                                                                                
                                                                                <tr>
                                                                                    <td class="featured-story__content-inner" style="padding: 32px 30px 45px;">
                                                                                        <table cellspacing="0" cellpadding="0">
                                                                                            <tr>
                                                                                                <td class="featured-story__heading featured-story--top__heading" style="background: #fff;" width="640" align="left">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Dear ${req.body.name},
                                                                                                            </td>
                                                                                                        </tr> 
    
                                                                                                        <tr>
                                                                                                            <td style="font-family: Geneva, Tahoma, Verdana, sans-serif; font-size: 22px; color: #464646;" width="400" align="left">
                                                                                                            Reference ID : ${orderNo}
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="featured-story__copy" style="background: #fff;" width="640" align="center">
                                                                                                    <table cellspacing="0" cellpadding="0">
                                                                                                        <tr>
                                                                                                            <td style="font-size: 16px; line-height: 22px; color: #555555; padding-top: 16px;" align="left">
                                                                                                            We acknowledge your registration with KS Academy for KSA FREE Mega Career Counselling Meet 2022.<br>
    
                                                                                                            CCM Selected Date: January 30, 2022 (Sunday)<br>
                                                                                                            Timing: 10:00 AM<br>
                                                                                                            Mode: Online (Zoom Meeting)<br>                                                                                                          
                                                                                                            For any queries, Contact - 988 433 6666, <br>	\                                                                                                            
                                                                                                            Thanks & Regards,<br>
                                                                                                            Team KSA<br>
                                                                                                               <br>
                                                                                                            </td>
                                                                                                        </tr>
                                                                                                    </table>
                                                                                                </td>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td class="button" style="text-align: center;font-size: 16px; padding-top: 26px;" width="640" align="left">
                                                                                                    <a href="https://ksacademy.co.in/">
                                                                                                        Visit website for more details
                                                                                                    </a>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </td>
                                                                                </tr>
                                                                            </table>
                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </table></td></tr></table></td>
                                                                        </tr>
                                
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                
                                                        <!-- Exact Target tracking code -->
                                
                                
                                                    </custom></body>
                                                    </html>`
                            };
                        }
                        transporter.sendMail(mailOptions, function (error, info) {
                            if (error) {
                                console.log(error);
                            } else {
                                console.log('email sent:' + info.res);
                            }
                        });
                        resolve({ success: true, message: "Order created" ,order:addOrder})
                    }
                    else{
                        reject({ success: false, message: "User already exists" })
                    }
            } catch (error) {
                reject({ success: false, message: "User already exists", error: error })
            }
        });
        promise.then(function (data) {
            res.send({ success: data.success, message: data.message ,order:data.order})
        }).catch(function (error) {
            res.send({ success: error ? error.success : false, message: error ? error.message : "User already exists", error: error })
        })
    }


    const userResendOtp = async function(req, res){
        let isValidParams = req.body.phonenumber
        let promise = new Promise(async function(resolve, reject){
            if (isValidParams) {
    
                // let phonenumber = req.body.phonenumber
                let getUser = await Booking.findOne({phonenumber:req.body.phonenumber})
            //     let otp = otpGenerator.generate(4, { upperCase: false, specialChars: false, alphabets: false })
            //    console.log(otp); 
                const sendOtp = new SendOtp(msg91AUth, 'Dear Customer, Your OTP is {{otp}}. Use this passcode to complete your transaction. Thank you. please do not share it with anybody');
                await sendOtp.retry("91"+getUser.phonenumber, false, function (error, data) {
                    console.log(data);
                    if(data.type="success"){
                        console.log("OTP Resent Succeed")
                        resolve({ success: true, message: 'OTP Resent' })
                    }
                    else{
                        console.log("OTP Resent Failed")
                        reject({ success: false, message: 'OTP Resent Failed' })
                    }
                  });
            }
            else{
                reject({ success: false, message: 'Provide Email and PhoneNummber' })
            }
        })
        promise.then(function (data) {
            console.log("success")
            res.send({ success: data.success, message: data.message })
        }).catch(function (error) {
            console.log({ error: error })
            res.send({ success: error ? error.success : false, message: error ? error.message : 'error occured while Resending Otp', error: error })
    
        })
    }


const viewUnlimitedBookings = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Booking.find()
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const getUnlimitedBookingCount = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Booking.count({status:"captured"})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}


// const sendOtp = async function (req, res) {

//     var numh= parseInt("" + 91 + req.body.phonenumber)
   
//     var options = {
//         "method": "GET",
//         "hostname": "api.msg91.com",
//         "port": null,
//         "path": `https://api.msg91.com/api/v5/otp?template_id=&mobile=${numh}&authkey=357733Abf3XvSy60633745P1`,
//         "headers": {
//           "content-type": "application/json"
//         }
//       };
      
//       var req = http.request(options, function (res) {
//         var chunks = [];
      
//         res.on("data", function (chunk) {
//           chunks.push(chunk);
//         });
      
//         res.on("end", function () {
//           var body = Buffer.concat(chunks);
//           console.log(body.toString());
//         });
//       });
      
//       req.write("{\"Value1\":\"Param1\",\"Value2\":\"Param2\",\"Value3\":\"Param3\"}");
//       req.end();
// }


module.exports={
    addUnlimitedOrderretelecast,
    addUnlimitedMeet,
    viewUnlimitedMeet,
    viewUnlimitedMeetbyId,
    UnlimitedMeetupdateCount,
    viewUnlimitedBookings,
    getUnlimitedBookingCount,
    // sendOtp,
    addUnlimitedOrderOtp,
    userVerifyOtp,
    userResendOtp
}