const Order = require('../model/bookings')
const nodemailer = require('nodemailer')
var otpGenerator = require('otp-generator')


const addOrder = async function (req, res) {
    console.log("first")
    console.log("addOrder",req.body)
    let promise = new Promise(async function (resolve, reject) {
        try {
            console.log("test")
                let email = req.body.email; 
                let otp = otpGenerator.generate(8, { upperCase: false, specialChars: false, alphabets: false })
                let orderNo =  otp;
                console.log('Order Number', orderNo)
                    console.log('run3')
                    let addOrder = await Order.create({
                        name:req.body.name,
                        board:req.body.board,
                        email:req.body.email,
                        phonenumber:req.body.phonenumber,
                        HighestDegree:req.body.HighestDegree,
                        gender:req.body.gender,
                        parentName:req.body.parentName,
                        parentPhone:req.body.parentPhone,
                        date:req.body.date,
                        timing:req.body.timing,
                        OrderId: orderNo,
                        amount: req.body.amount,
                        ccmeet:req.body.ccmeet,
                        city:req.body.city,

                        partiattending:req.body.partiattending,
                        parti:req.body.parti,
                        school:req.body.school,
                        dob:req.body.dob,
                        collegename:req.body.collegename,
                        stream:req.body.stream,
                        
                    

                        state:req.body.state,
                        address:req.body.address,
                        reference:req.body.reference,
                        razorpayOrderId: "",
                        razorpayPaymentId: ""
                    })
                    console.log("order Details",addOrder)
                    if(addOrder){
                    console.log(addOrder)
                    resolve({ success: true, message: "Order created" ,order:addOrder})
                }
                else{
                    reject({ success: false, message: "Order not Created" })
                }
        } catch (error) {
            reject({ success: false, message: "User already exists", error: error })
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message ,order:data.order})
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "User already exists", error: error })
    })
}

const viewOrder = async function (req, res) {
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewOrder = await Order.find()
                    resolve({ success: true, orders: viewOrder })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, orders: data.orders })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const adminViewOrder = async function (req, res) {
    // let isValidtoken = req.headers.token
    let promise = new Promise(async function (resolve, reject) {
        try {
            // if (isValidtoken) {
            //     let adminId = jwt.verify(req.headers.token, secret)
            //     console.log("test1", adminId)
            //     let checkAdmin = await Admin.findOne({ _id: adminId._id })
            //     console.log("test2", checkAdmin)
            //     if (checkAdmin) {
                    let viewOrder = await Order.find()
                    resolve({ success: true, adminInOrders: viewOrder })
                // } else {
                //     reject({ success: false, message: 'Admin ID Invalid' })
                // }
            // } else {
            //     reject({ success: false, message: "Token Invalid" })
            // }
        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, adminInOrders: data.adminInOrders })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}

const viewOrderbyId = async function (req, res) {
        // let isValidtoken = req.headers.token
    let promise = new Promise(async function (resolve, reject) {
        try {
                        // if (isValidtoken) {
            //     let adminId = jwt.verify(req.headers.token, secret)
            //     console.log("test1", adminId)
            //     let checkAdmin = await Admin.findOne({ _id: adminId._id })
            //     console.log("test2", checkAdmin)
            //     if (checkAdmin) {
            let viewOrder = await Order.findOne({orderId:req.body.orderId})
            resolve({ success: true, userOrders: viewOrder })
                            // } else {
                //     reject({ success: false, message: 'Admin ID Invalid' })
                // }
            // } else {
            //     reject({ success: false, message: "Token Invalid" })
            // }
        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, order: data.userOrders })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const getCapturedOnetoOneBookingCount = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Order.count({status:"captured",ccmeet:"1to1"})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const getUncapturedOnetoOneBookingCount = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Order.count({status:{$ne:"captured"},ccmeet:"1to1"})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const getCapturedLimitedBookingCount = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Order.count({status:"captured",ccmeet:"limited"})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}
const getUncapturedLimitedBookingCount = async function (req, res) {
    var recentDate = new Date();
    let promise = new Promise(async function (resolve, reject) {
        try {
                console.log("test2")
                    let viewMeet = await Order.count({status:{$ne:"captured"},ccmeet:"limited"})
                    resolve({ success: true, meet: viewMeet })

        } catch (error) {
            reject({ success: false, message: "Error Occured while Listing Data", error: error })
            console.log(error)
        }
    });
    promise.then(function (data) {
        res.send({ success: data.success, message: data.message, meet: data.meet })
    }).catch(function (error) {
        res.send({ success: error ? error.success : false, message: error ? error.message : "Error Occured while Listing Data", error: error })

    })
}

module.exports={
    addOrder,
    viewOrder,
    viewOrderbyId,
    getCapturedOnetoOneBookingCount,
    getUncapturedOnetoOneBookingCount,
    getCapturedLimitedBookingCount,
    getUncapturedLimitedBookingCount
}